package calendarapplication;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JPanel;




public class CalendarApplication {    
 
    //for create image on the frame
    public static class ImagePanel extends JPanel {        
        Image image;
        public void SetBackground(Image image) {
            this.image = image;
        }
        @Override
        public void paintComponent(Graphics G) {
            super.paintComponent(G);
            G.drawImage(image, 0, 0, this.getWidth(), this.getHeight(), null);
        }
    }
          
    //create main frame
    public static class PaintMainFrame extends JFrame  {
            JPanel CloseTurn;
            JPanel TopPanel = new JPanel();
            JPanel ChangeYearPanel = new JPanel();
            JPanel BottomPanel = new JPanel();
            ImageIcon icon1 = new ImageIcon("images\\WEEK_1.png");;
            ImageIcon icon2 = new ImageIcon("images\\MONTH_YEAR_1.png");
            ImageIcon icon3 = new ImageIcon("images\\MONTH_YEAR_1.png");
            ImageIcon icon4 = new ImageIcon("images\\SET.png");
            ImageIcon iconTurn = new ImageIcon("images\\Turn.png");
            ImageIcon iconClose = new ImageIcon("images\\Close.png");
            Image img1;
            Image img2;
            Image img3;
            Image img4;
            Image img5;
            Image img6;
            JButton buttonWeek = new JButton();
            JButton buttonMonth = new JButton();
            JButton buttonYear = new JButton();;
            JButton buttonSettings = new JButton();;
            JButton Turn = new JButton();;
            JButton Close = new JButton();
        
    	PaintMainFrame() {
            super("Calendar");           
            ImagePanel backgroundPanel = null; 
            try {                
                backgroundPanel = new ImagePanel();
                backgroundPanel.SetBackground(ImageIO.read(new File("images\\M.png")));
                this.setOpacity(1);
    	    } catch (IOException e) {
    	    } 
            setDefaultCloseOperation(EXIT_ON_CLOSE); 
                                
            img1 = icon1.getImage();
            img2 = icon2.getImage();
            img3 = icon3.getImage() ;
            img4 = icon4.getImage();
            img5 = iconTurn.getImage();
            img6 = iconClose.getImage();
           
            icon1 = new ImageIcon(img1);
            icon2 = new ImageIcon(img2);
            icon3 = new ImageIcon(img3);
            icon4 = new ImageIcon(img4);
            iconTurn = new ImageIcon(img5);
            iconClose = new ImageIcon(img6); 
            
        //**************************BUTTONS START***************************
            //button "week"
            //buttonWeek.setIcon(icon1);
//            buttonWeek.setText("Week"); 
//            buttonWeek.setFont(new Font("Arial", Font.PLAIN, 40));
//            buttonWeek.setHorizontalTextPosition(AbstractButton.CENTER);          
                                          
            //button "month"
            //buttonMonth.setIcon(icon2); 
//            buttonMonth.setText("Month"); 
//            buttonMonth.setFont(new Font("Arial", Font.PLAIN, 40));
//            buttonMonth.setHorizontalTextPosition(AbstractButton.CENTER);
            
            //button "year"
            //buttonYear.setIcon(icon2);
//            buttonYear.setText("Year"); 
//            buttonYear.setFont(new Font("Arial", Font.PLAIN, 40));
//            buttonYear.setHorizontalTextPosition(AbstractButton.CENTER);           
           
            //button "set"
            //buttonSettings.setIcon(icon4);        
            //BottomPanel.add(buttonSettings);
             
            //arrow-button left
//            JButton ButtonLeft = new JButton();
//            ButtonLeft.setIcon(new ImageIcon("images\\Left.png"));
//            ButtonLeft.setPressedIcon(new ImageIcon("images\\LeftPr.png"));
//            ButtonLeft.setRolloverIcon(new ImageIcon("images\\LeftPr.png"));
//            ButtonLeft.setBorderPainted(false);
//            ButtonLeft.setFocusPainted(false);
//            ButtonLeft.setContentAreaFilled(false);
                       
            //arrow-button right
//            JButton ButtonRight = new JButton();
//            ButtonRight.setIcon(new ImageIcon("images\\Right.png"));
//            ButtonRight.setPressedIcon(new ImageIcon("images\\RightPr.png"));
//            ButtonRight.setRolloverIcon(new ImageIcon("images\\RightPr.png"));
//            ButtonRight.setBorderPainted(false);
//            ButtonRight.setFocusPainted(false);
//            ButtonRight.setContentAreaFilled(false);
            
            //close and turn buttons under each other on the right top
//            Turn.setBorderPainted(false);
//            Turn.setFocusPainted(false);
//            Turn.setContentAreaFilled(false);
                      
//            Close.setBorderPainted(false);
//            Close.setFocusPainted(false);
//            Close.setContentAreaFilled(false);
            //**********************BUTTONS END*********************************        
                                                                                          
            backgroundPanel.setLayout(null);             
            
            
            //************************CloseTurn Panel***************************
            CloseTurn = new JPanel();
            CloseTurn.setLayout(new GridBagLayout());
            CloseTurn.setOpaque(false);
            setSizeCloseTurnPanel(CloseTurn);          
            GridBagConstraints ct = new GridBagConstraints();
            Turn = new JButton();
            Turn.setIcon(iconTurn);
            ct.weightx = 0.25;
            ct.weighty = 0.25;
            ct.fill = GridBagConstraints.BOTH;
            ct.gridx = 0;
            ct.gridy = 0;
            Turn.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                JButton B = (JButton) e.getComponent();
                Dimension sizeCC = B.getSize();
                System.out.println("sizeTurn = " +  sizeCC);
                Image scaled = img5.getScaledInstance(sizeCC.width, sizeCC.height, java.awt.Image.SCALE_SMOOTH);
                B.setIcon(new ImageIcon(scaled));
            };});
            CloseTurn.add(Turn, ct);
            
            Close = new JButton();
            Close.setIcon(iconClose);
            ct.weightx = 0.25;
            ct.weighty = 0.25;
            ct.fill = GridBagConstraints.BOTH;
            ct.gridx = 1;
            ct.gridy = 0;
            Close.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                JButton btnCT = (JButton) e.getComponent();
                Dimension sizeCT = btnCT.getSize();
                Image scaled = img6.getScaledInstance(sizeCT.width, sizeCT.height, java.awt.Image.SCALE_SMOOTH);
                btnCT.setIcon(new ImageIcon(scaled));
            };});
            CloseTurn.add(Close, ct);
            backgroundPanel.add(CloseTurn); 
            //************************end closeTurn panel***********************
         
            
            
            
            //***************************bottom panel***************************
            BottomPanel.setLayout(new GridBagLayout());
            setSizeBottomPanel(BottomPanel);
            BottomPanel.setBackground(Color.red);
            BottomPanel.setOpaque(false);
            GridBagConstraints c = new GridBagConstraints(); 

            buttonWeek = new JButton();
            buttonWeek.setIcon(icon1);
            buttonWeek.setPressedIcon(new ImageIcon("images\\WeekPr.png"));
            buttonWeek.setRolloverIcon(new ImageIcon("images\\WeekPr.png"));
            buttonWeek.setBorderPainted(false);
            buttonWeek.setFocusPainted(false);
            buttonWeek.setContentAreaFilled(false);
            c.weightx = 0.25;
            c.weighty = 0.25;
            c.fill = GridBagConstraints.BOTH;
            c.gridx = 0;
            c.gridy = 0;
            buttonWeek.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                JButton btn1 = (JButton) e.getComponent();
                Dimension size1 = btn1.getSize();
                Image scaled = img1.getScaledInstance(size1.width, size1.height, java.awt.Image.SCALE_SMOOTH);
                //Image scaled_2 = img1.getScaledInstance(size1.width, size1.height, java.awt.Image.SCALE_SMOOTH);
                btn1.setIcon(new ImageIcon(scaled));
            };});
            BottomPanel.add(buttonWeek, c);
        
            buttonMonth = new JButton();
            buttonMonth.setIcon(icon2);
            buttonMonth.setPressedIcon(new ImageIcon("images\\MonthAndYearPr.png"));
            buttonMonth.setRolloverIcon(new ImageIcon("images\\MonthAndYearPr.png"));
            buttonMonth.setBorderPainted(false);
            buttonMonth.setFocusPainted(false);
            buttonMonth.setContentAreaFilled(false);
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 0.25;
            c.weighty = 0.25;
            c.gridx = 1;
            c.gridy = 0;
            buttonMonth.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                JButton btn2 = (JButton) e.getComponent();
                Dimension size2 = btn2.getSize();
                Image scaled = img2.getScaledInstance(size2.width, size2.height, java.awt.Image.SCALE_SMOOTH);
                btn2.setIcon(new ImageIcon(scaled));
                };});
            BottomPanel.add(buttonMonth, c);
        
            buttonYear = new JButton();
            buttonYear.setIcon(icon2);
            buttonYear.setPressedIcon(new ImageIcon("images\\MonthAndYearPr.png"));
            buttonYear.setRolloverIcon(new ImageIcon("images\\MonthAndYearPr.png"));
            buttonYear.setBorderPainted(false);
            buttonYear.setFocusPainted(false);
            buttonYear.setContentAreaFilled(false);
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 0.25;
            c.weighty = 0.25;
            c.gridx = 2;
            c.gridy = 0;
            buttonYear.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                JButton btn3 = (JButton) e.getComponent();
                Dimension size3 = btn3.getSize();
                Image scaled = img3.getScaledInstance(size3.width, size3.height, java.awt.Image.SCALE_SMOOTH);
                btn3.setIcon(new ImageIcon(scaled));
                };}); 
            BottomPanel.add(buttonYear, c);
        
            buttonSettings = new JButton();
            buttonSettings.setIcon(icon4);
            buttonSettings.setPressedIcon(new ImageIcon("images\\SetPr.png"));
            buttonSettings.setRolloverIcon(new ImageIcon("images\\SetPr.png"));
            buttonSettings.setBorderPainted(false);
            buttonSettings.setFocusPainted(false);
            buttonSettings.setContentAreaFilled(false);
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 0.25;
            c.weighty = 0.25;
            c.gridx = 3;
            c.gridy = 0;
            buttonSettings.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                JButton btn4 = (JButton) e.getComponent();
                Dimension size4 = btn4.getSize();
                Image scaled = img4.getScaledInstance(size4.width, size4.height, java.awt.Image.SCALE_SMOOTH);
                btn4.setIcon(new ImageIcon(scaled));
                };});
            BottomPanel.add(buttonSettings, c);          
            backgroundPanel.add(BottomPanel);
            //******************************************************************
            


            //****************************************************************** 
            CalendarTable tb = new CalendarTable();
            tb.changeYearPanel.setBackground(Color.red);
            backgroundPanel.add(tb.changeYearPanel);
            //******************************************************************
            
            
            
            //******************************************************************
            //tb.nextPrevPanel.setLayout(new GridBagLayout());
            //tb.nextPrevPanel.setSize(1110, 90);
            //tb.nextPrevPanel.setLocation(30,160);
            //tb.nextPrevPanel.setBackground(Color.ORANGE);
            //setSizeNextPrevPanel(tb.nextPrevPanel);
            backgroundPanel.add(tb.nextPrevPanel);  
            //******************************************************************
            
            
            
            //******************************************************************
            //CloseTurn = new JPanel();
            //CloseTurn.setBackground(Color.blue);
            //CloseTurn.setSize(180,60);
            //CloseTurn.setLocation(980, 30);            
            //******************************************************************
            

            setContentPane(backgroundPanel);
            pack();            
    	    setVisible(true);        
        }
    }
    //get rezolution of the screen
    public static Dimension getRezolution(){        
        Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
        System.out.println(size);
        return (size);        
    }
    //get needed size of frame
    public static int FrameHeight(Dimension exSize){
        System.out.println(exSize.height*2/3);
        return(exSize.height*2/3);
    }
    //set icon on the frame and application's icon
    private static void SetApplicationIcon(JFrame frame) {
        Image im = Toolkit.getDefaultToolkit().getImage("images\\48.png");
        frame.setIconImage(im);
        frame.show();
    } 
    public static JPanel setSizeBottomPanel(JPanel pane) {  
        Dimension size = new Dimension();
        size.height = (int)(FrameHeight(getRezolution())/12); 
        size.width  = (int)(2*FrameHeight(getRezolution())/3);
        
        Point location = new Point();
        location.x = (int)(0.15*FrameHeight(getRezolution()));
        location.y = (int)(199*FrameHeight(getRezolution())/240 - 5);        
        
        pane.setSize(size);
        pane.setLocation(location);
        return (pane); 
    }    
    public static JPanel setSizeChangeYearPanel(JPanel pane) {
        Dimension size = new Dimension();
        size.width  = (int)(5*FrameHeight(getRezolution())/24);
        size.height = (int)(0.05*FrameHeight(getRezolution())); 
               
        Point location = new Point();
        location.x = (int)(0.025*FrameHeight(getRezolution()));
        location.y = (int)(0.2125*FrameHeight(getRezolution()));        
        
        pane.setSize(size);
        pane.setLocation(location);    
        return (pane); 
    } 
    public static JPanel setSizeNextPrevPanel(JPanel pane) {
        Dimension size = new Dimension();
        size.width  = (int)(0.925*FrameHeight(getRezolution()));
        size.height = (int)(0.075*FrameHeight(getRezolution())); 
               
        Point location = new Point();
        location.x = (int)(0.026*FrameHeight(getRezolution()));
        location.y = (int)(2*FrameHeight(getRezolution())/15);        
        
        pane.setSize(size);
        pane.setLocation(location);   
        return (pane); 
    }
    public static JButton setSizeButtonsNextPrevPanel(JButton button) {
        Dimension size = new Dimension();
        size.width  = (int)(0.925*FrameHeight(getRezolution())/3);
        size.height = (int)(0.075*FrameHeight(getRezolution()));       
        
        button.setSize(size); 
        return (button); 
    } 
    public static JPanel setSizeCloseTurnPanel(JPanel pane) {
        Dimension size = new Dimension();
        size.width  = (int)(0.15*FrameHeight(getRezolution()));
        size.height = (int)(0.05*FrameHeight(getRezolution())); 
               
        Point location = new Point();
        location.x = (int)(49*FrameHeight(getRezolution())/60);
        location.y = (int)(FrameHeight(getRezolution())/40);        
        
        pane.setSize(size);
        pane.setLocation(location);   
        return (pane); 
    }
    
    
    public static void main(String[] args) {
        PaintMainFrame frame = new PaintMainFrame();
        JFrame.setDefaultLookAndFeelDecorated(true);
        frame.setSize(FrameHeight(getRezolution()),FrameHeight(getRezolution()));
        SetApplicationIcon(frame);
    }    
}